import React, { useState, useEffect } from 'react';

import feedbackServiceObject from "../services/feedback-service";

export const TechnologyFeedback = () => {
    let title = "Feedback Of - Angular Framework!";
    const [questions, setQuestions] = useState([]);
    const [index, setIndex] = useState(0);
    const [userVote, setUserVote] = useState(1);

    useEffect(() => {
        (async () => {
            try {
                setQuestions(await feedbackServiceObject.getAngularQuestions());    
            } catch (error) {
                console.log(error);
            }
            
        })();
    }, []);
    let answerChanged = (e) => {
        setUserVote(e.target.value);
    }
    let nextQuestion = () => {
        let answer = {
            "questionId": questions[index].questionId,
            "technologyId": 1,
            "userVote": Number.parseInt(userVote)
        }
        sessionStorage.setItem(questions[index].questionId, JSON.stringify(answer));
        setIndex(index + 1);
        if (index === questions.length - 1) {
            const keys = Object.keys(sessionStorage);
            const allAnswers = [];
            for (let key of keys) {
                allAnswers.push(JSON.parse(sessionStorage.getItem(key)));
            }
            try {
                (async () => {
                    feedbackServiceObject.registerFinalFeedback(allAnswers);
                })();                
            } catch (error) {
                console.log(error);
            }
        }
    }
    if (questions.length > index) {
        return (
            <div >
                <h1>{title}</h1>
                <hr />
                <table className="table table-hover">
                    <thead>
                        <tr>
                            <th>{questions[index].question}</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            questions[index].answers.map((answer, index) => {
                                return <tr key={index}>
                                    <td>
                                        <div className="form-check">
                                            <label className="form-check-label">
                                                <input type="radio" className="form-check-input" name="vote"
                                                    key={index}
                                                    onChange={answerChanged}
                                                    value={answer.value}
                                                />
                                                {answer.text}
                                            </label>
                                        </div>
                                    </td>
                                </tr>
                            })
                        }
                        <tr>
                            <td>
                                <button className="btn btn-dark" onClick={(e) => nextQuestion(e)}>Next Question</button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div >
        )
    } else {
        return (<h1>Thank you for your feedback!</h1>)
    }
}