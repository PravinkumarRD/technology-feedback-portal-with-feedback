import axios from "axios";

class FeedbackService {
  async getAngularQuestions() {
    try {
      return await (
        await axios.get("http://localhost:9090/api/feedback/ngquestions")
      ).data;      
    } catch (error) {
      throw new Error(error);
    }

  }
  async registerFinalFeedback(feedbackResult) {
    try {
      return await (
        await axios.post(
          "http://localhost:9090/api/feedback/finalfeedback",
          feedbackResult
        )
      ).data;      
    } catch (error) {
      throw new Error(error);
    }
  }
}

export default new FeedbackService();
