//import { TechnologyList } from "./technology/components/TechnologyList";

import { TechnologyFeedback } from "./feedback/components/TechnologyFeedback";
function App() {
  return (
    <div>
      {/* <TechnologyList /> */}
      <TechnologyFeedback/>
    </div>
  );
}

export default App;
